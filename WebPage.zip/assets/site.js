// assets/site.js
// Reserved for future small enhancements (no build step).
