# Documentation Audit Report

## Summary

Goal: streamline the documentation set, remove internal/unprofessional material, and ensure technical accuracy against the repository source.

**Result:** reduced the docs from 17 pages to 7 consolidated, user-focused pages plus this report.

## Phase 1 — Inventory and triage

### Docs inventory (excluding README.md)

The following documentation pages were found in the repository snapshot:

- `index.md`
- `quickstart.md`
- `first-scan.md`
- `self-scan.md`
- `scan-a-subnet.md`
- `scan-ports.md`
- `traceroute.md`
- `verbosity.md`
- `cli.md`
- `output.md`
- `troubleshooting.md`
- `how-it-works.md`
- `design-limitations.md`
- `security-ethics.md`
- `developer-guide.md`
- `docs-maintenance.md`
- `docstrings.md`

### Mapping to current navbar

All of the above map cleanly to the provided navbar except:

- **Reference → API reference**: no API doc page exists in this snapshot.
- **Project → AI usage** and **Meeting transcripts**: no corresponding docs pages exist in this snapshot.

### Page-by-page triage decisions

| Page | Audience | Decision | Notes |
|---|---|---|---|
| `index.md` | Users | KEEP | Rewritten as a concise project overview. |
| `quickstart.md` | Users | KEEP | Rewritten; corrected install/run examples. |
| `first-scan.md` | Users | MERGE | Merged into `tutorials.md`. |
| `self-scan.md` | Users | MERGE | Merged into `tutorials.md`. |
| `scan-a-subnet.md` | Users | MERGE | Merged into `how-to.md`. |
| `scan-ports.md` | Users | MERGE | Merged into `how-to.md`. |
| `traceroute.md` | Users | MERGE | Merged into `how-to.md`. |
| `verbosity.md` | Users | MERGE | Merged into `how-to.md` and `reference.md`. |
| `cli.md` | Users | MERGE | Merged into `reference.md`. |
| `output.md` | Users | MERGE | Merged into `reference.md`. |
| `troubleshooting.md` | Users | MERGE | Merged into `reference.md`. |
| `how-it-works.md` | Users | MERGE | Merged into `concepts.md`. |
| `design-limitations.md` | Users | MERGE | Merged into `concepts.md` and `reference.md`. |
| `security-ethics.md` | Users | MERGE | Merged into `concepts.md`. |
| `developer-guide.md` | Developers | MERGE | Merged into `development.md` and tightened for professionalism. |
| `docs-maintenance.md` | Developers | MERGE | Merged into `development.md`; removed “maintenance/admin” tone. |
| `docstrings.md` | Developers | MERGE | Merged into `development.md` as a short docstring style section. |

## Phase 1 output — New information architecture

### Final recommended MkDocs nav (mkdocs.yml `nav:` snippet)

```yaml
nav:
  - Home: index.md
  - Getting started:
      - Quickstart: quickstart.md
      - Tutorials: tutorials.md
  - How-to: how-to.md
  - Reference: reference.md
  - Concepts: concepts.md
  - Development: development.md
```

### Merge / rename / move map

The docs were consolidated without directory moves (files remain in the docs root):

- `first-scan.md` → merged into `tutorials.md`
- `self-scan.md` → merged into `tutorials.md`
- `scan-a-subnet.md` → merged into `how-to.md`
- `scan-ports.md` → merged into `how-to.md`
- `traceroute.md` → merged into `how-to.md`
- `verbosity.md` → merged into `how-to.md` and `reference.md`
- `cli.md` → merged into `reference.md`
- `output.md` → merged into `reference.md`
- `troubleshooting.md` → merged into `reference.md`
- `how-it-works.md` → merged into `concepts.md`
- `design-limitations.md` → merged into `concepts.md` and `reference.md`
- `security-ethics.md` → merged into `concepts.md`
- `developer-guide.md` → merged into `development.md`
- `docs-maintenance.md` → merged into `development.md`
- `docstrings.md` → merged into `development.md`

### Delete list (docs pages removed from the set)

These files should be removed from the public docs tree after you adopt the new nav:

- `first-scan.md` — merged into `tutorials.md`
- `self-scan.md` — merged into `tutorials.md`
- `scan-a-subnet.md` — merged into `how-to.md`
- `scan-ports.md` — merged into `how-to.md`
- `traceroute.md` — merged into `how-to.md`
- `verbosity.md` — merged into `how-to.md` / `reference.md`
- `cli.md` — merged into `reference.md`
- `output.md` — merged into `reference.md`
- `troubleshooting.md` — merged into `reference.md`
- `how-it-works.md` — merged into `concepts.md`
- `design-limitations.md` — merged into `concepts.md` / `reference.md`
- `security-ethics.md` — merged into `concepts.md`
- `developer-guide.md` — merged into `development.md`
- `docs-maintenance.md` — merged into `development.md`
- `docstrings.md` — merged into `development.md`

## Phase 2 — Accuracy audit (evidence map)

### Evidence map (source-of-truth locations)

Primary sources used to verify and correct documentation:

- CLI parsing and validation: `src/argParser.py` (`ParseClass.buildParser`, `ParseClass.parser`, `ParseClass.parsePorts`)
- Runtime scan flow: `src/main.py` (`main`)
- Scanning implementations: `src/networkScanner.py` (`ARPHostDetect`, `ICMPHostScanner`, `ICMPHostIdentifier`, `TCPPortScanner`, `TraceRouteScanner`)
- Output formatting: `src/generateReport.py` (`Report.print_*` methods)
- Dependency list: `requirements.txt`

### Notable corrections made (with evidence pointers)

1) **`--scanType=all` requires `--ports`**
   - The entrypoint requires ports for any scan type that includes TCP scanning (for example `all` and `TCP`). If `--ports` is omitted, `src/main.py` raises `RuntimeError("No ports given to scan.")`.
   - Evidence: `src/main.py` line 90; `src/networkScanner.py` `TCPPortScanner.scan()` lines 31–37 (validates a non-empty port list).


2) **`--ports` is a single string; spaces are not supported**
   - Port parsing supports comma-separated lists and ranges, but argparse passes `--ports` as one string.
   - Evidence: `src/argParser.py` `ParseClass.parsePorts()` lines 202–245; `ParseClass.buildParser()` defines `--ports` as a single argument (lines 23–48).

3) **`-h/--help` does not print help**
   - Help is parsed as a boolean, but no help output is produced.
   - Evidence: `src/argParser.py` `buildParser()` lines 23–48 (`add_help=False` plus a custom help flag); `src/main.py` does not print usage.

4) **Self Scan runs first during `all` scans; `SelfScan`-only mode exits early**
   - Evidence: `src/main.py` lines 20–29 (Self Scan block) and line 29 (early return in `scanType == 6`).

5) **Traceroute-only mode requires `--hostid=NONE` and exits after printing traceroute**
   - Evidence: `src/main.py` lines 58–80.

6) **TCP traceroute always targets destination port 80**
   - Evidence: `src/networkScanner.py` `TraceRouteScanner.TCPtrace()` lines 480–520.

7) **Traceroute output printing expects 3 values per hop**
   - Evidence: `src/generateReport.py` `Report.printTraceroute()` lines 140–150.
   - Note: `TraceRouteScanner.ICMPtrace()` sometimes appends a 2-tuple on timeout, which can cause a print/unpack error if mixed with successful hops.

### README and repository mismatch notes

- The provided `README.md` references `misc/requirements.txt`, but the repository snapshot contains `requirements.txt` at the root.
- The provided `README.md` includes an example `all` scan invocation without `--ports`; the code requires `--ports` for `all` scans.

These were treated as documentation issues in the docs pages (README was not edited).

## Links

### Broken links fixed

- The consolidated docs set uses new cross-links (`index.md` → `quickstart.md`, `tutorials.md`, `how-to.md`, `reference.md`, `concepts.md`, `development.md`).
- All internal links in the new pages point to the new consolidated pages.

### Remaining broken references

None found in the new docs set.

## Missing/unavailable files

The work order referenced additional repository items (for example, `mkdocs.yml`, `runApplication.sh`, and test scripts). Those were not present in the repository snapshot provided to this audit, so the docs avoid referencing them.

## Open questions checklist

Only needed if these apply to your repo:

- Confirm where MkDocs pulls docs from (commonly `docs/`). This ZIP assumes these pages live in the docs root.
- If you do have `mkdocs.yml`, ensure the `nav:` structure is updated to match the snippet above.
